package com.privateadmin.android.data

import com.google.firebase.database.FirebaseDatabase
import kotlinx.coroutines.tasks.await

class FirebaseRepository {
    private val db = FirebaseDatabase.getInstance().reference
    private val users = db.child("users")
    private val settings = db.child("settings")

    // ========== USER FUNCTIONS ==========
    
    suspend fun getUsers(): List<AdminUser> {
        val snap = users.get().await()
        return snap.children.map { u ->
            AdminUser(
                deviceId = u.key.orEmpty(),
                packageName = u.child("packageName").getValue(String::class.java).orEmpty(),
                online = u.child("online").getValue(Boolean::class.java) ?: false,
                lastLogin = u.child("lastLogin").getValue(Long::class.java) ?: 0L,
                status = u.child("status").getValue(String::class.java) ?: "active"
            )
        }
    }

    suspend fun saveUser(user: AdminUser) {
        val data = mapOf(
            "packageName" to user.packageName,
            "online" to user.online,
            "lastLogin" to user.lastLogin,
            "status" to user.status,
            "updatedAt" to System.currentTimeMillis()
        )
        users.child(user.deviceId).updateChildren(data).await()
    }

    suspend fun setUserStatus(deviceId: String, status: String) {
        users.child(deviceId).child("status").setValue(status).await()
    }

    suspend fun deleteUser(deviceId: String) {
        users.child(deviceId).removeValue().await()
    }

    suspend fun createUser(email: String): String {
        val key = users.push().key ?: throw Exception("Failed to generate UID")
        val data = mapOf(
            "email" to email,
            "status" to "active",
            "packageName" to "",
            "online" to false,
            "lastLogin" to System.currentTimeMillis(),
            "createdAt" to System.currentTimeMillis()
        )
        users.child(key).setValue(data).await()
        return key
    }

    // ========== SETTINGS FUNCTIONS ==========
    
    suspend fun getSettings(): AppSettings {
        val snap = settings.get().await()
        val features = snap.child("features").children.mapNotNull { it.getValue(String::class.java) }
        return AppSettings(
            title = snap.child("title").getValue(String::class.java) ?: "Private Login",
            contact = snap.child("contact").getValue(String::class.java) ?: "",
            features = features,
            paymentApiUrl = snap.child("paymentApiUrl").getValue(String::class.java)
                ?: snap.child("payment_api_url").getValue(String::class.java).orEmpty(),
            appId = snap.child("appId").getValue(String::class.java)
                ?: snap.child("app_id").getValue(String::class.java).orEmpty()
        )
    }

    suspend fun saveSettings(value: AppSettings) {
        settings.updateChildren(mapOf(
            "title" to value.title,
            "contact" to value.contact,
            "paymentApiUrl" to value.paymentApiUrl,
            "appId" to value.appId
        )).await()
    }

    // ========== SUBSCRIPTION FUNCTIONS ==========

    suspend fun getSubscriptions(): List<Subscription> {
        val snap = db.child("admin").child("subscriptions").get().await()
        return snap.children.map { item ->
            Subscription(
                id = item.key.orEmpty(),
                name = item.child("name").getValue(String::class.java)
                    ?: item.child("title").getValue(String::class.java).orEmpty(),
                amount = item.child("amount").getValue(Double::class.java)
                    ?: item.child("amount").getValue(Long::class.java)?.toDouble()
                    ?: item.child("price").getValue(Double::class.java)
                    ?: 0.0,
                currency = item.child("currency").getValue(String::class.java) ?: "UGX",
                description = item.child("description").getValue(String::class.java).orEmpty(),
                durationDays = item.child("durationDays").getValue(Int::class.java) ?: 30,
                active = item.child("active").getValue(Boolean::class.java) ?: true
            )
        }.sortedBy { it.amount }
    }

    suspend fun saveSubscription(value: Subscription) {
        require(value.name.isNotBlank()) { "Subscription name is required" }
        require(value.amount > 0) { "Amount must be greater than zero" }
        require(value.durationDays > 0) { "Duration must be greater than zero" }
        val id = value.id.ifBlank {
            db.child("admin").child("subscriptions").push().key
                ?: throw IllegalStateException("Could not create subscription ID")
        }
        db.child("admin").child("subscriptions").child(id).setValue(mapOf(
            "name" to value.name.trim(),
            "amount" to value.amount,
            "currency" to value.currency.trim().ifBlank { "UGX" },
            "description" to value.description.trim(),
            "durationDays" to value.durationDays,
            "active" to value.active,
            "updatedAt" to System.currentTimeMillis()
        )).await()
    }

    suspend fun deleteSubscription(id: String) {
        db.child("admin").child("subscriptions").child(id).removeValue().await()
    }
}