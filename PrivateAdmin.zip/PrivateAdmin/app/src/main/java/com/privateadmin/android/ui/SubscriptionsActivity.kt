package com.privateadmin.android.ui

import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.privateadmin.android.R
import com.privateadmin.android.data.FirebaseRepository
import com.privateadmin.android.data.Subscription
import kotlinx.coroutines.launch

class SubscriptionsActivity : AppCompatActivity() {
    private val repo = FirebaseRepository()
    private lateinit var list: LinearLayout
    private lateinit var empty: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 18, 20, 20)
            setBackgroundColor(0xFFF5F7FB.toInt())
        }
        val top = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        top.addView(TextView(this).apply {
            text = "Subscriptions"
            textSize = 24f
            setTextColor(0xFF172554.toInt())
            setTypeface(null, android.graphics.Typeface.BOLD)
        }, LinearLayout.LayoutParams(0, -2, 1f))
        top.addView(Button(this).apply { text = "ADD PLAN"; setOnClickListener { editPlan(null) } })
        root.addView(top)
        root.addView(TextView(this).apply {
            text = "Manage the plans shown in the Android payment dialog. Changes are saved to the shared database."
            textSize = 13f; setTextColor(0xFF64748B.toInt()); setPadding(0, 8, 0, 14)
        })
        empty = TextView(this).apply { text = "No subscription plans yet. Add your first plan."; textSize = 15f; setTextColor(0xFF64748B.toInt()); gravity = Gravity.CENTER; setPadding(12, 32, 12, 32) }
        root.addView(empty)
        val scroll = ScrollView(this)
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        loadPlans()
    }

    private fun loadPlans() {
        lifecycleScope.launch {
            try {
                val plans = repo.getSubscriptions()
                list.removeAllViews()
                empty.visibility = if (plans.isEmpty()) View.VISIBLE else View.GONE
                plans.forEach { plan ->
                    val card = LinearLayout(this@SubscriptionsActivity).apply {
                        orientation = LinearLayout.VERTICAL
                        setPadding(16, 14, 16, 14)
                        setBackgroundResource(R.drawable.bg_card)
                        val params = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 12 }
                        layoutParams = params
                    }
                    card.addView(TextView(this@SubscriptionsActivity).apply {
                        text = plan.name
                        textSize = 18f; setTypeface(null, android.graphics.Typeface.BOLD); setTextColor(0xFF172554.toInt())
                    })
                    card.addView(TextView(this@SubscriptionsActivity).apply {
                        text = "${plan.currency} ${plan.amount}  •  ${plan.durationDays} days\n${plan.description}\n${if (plan.active) "ACTIVE" else "INACTIVE"}"
                        textSize = 13f; setTextColor(0xFF64748B.toInt()); setPadding(0, 5, 0, 8)
                    })
                    val actions = LinearLayout(this@SubscriptionsActivity).apply { gravity = Gravity.END }
                    actions.addView(Button(this@SubscriptionsActivity).apply { text = if (plan.active) "DEACTIVATE" else "ACTIVATE"; setOnClickListener { save(plan.copy(active = !plan.active)) } })
                    actions.addView(Button(this@SubscriptionsActivity).apply { text = "EDIT"; setOnClickListener { editPlan(plan) } })
                    actions.addView(Button(this@SubscriptionsActivity).apply { text = "DELETE"; setOnClickListener { confirmDelete(plan) } })
                    card.addView(actions)
                    list.addView(card)
                }
            } catch (e: Exception) {
                Toast.makeText(this@SubscriptionsActivity, "Could not load subscriptions: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun editPlan(existing: Subscription?) {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(22, 8, 22, 0) }
        fun field(hint: String, value: String = "", inputType: Int = android.text.InputType.TYPE_CLASS_TEXT): EditText {
            return EditText(this).apply { this.hint = hint; setText(value); this.inputType = inputType; isSingleLine = true }
        }
        val name = field("Plan name", existing?.name.orEmpty())
        val amount = field("Price amount", existing?.amount?.toString().orEmpty(), android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL)
        val currency = field("Currency (e.g. UGX)", existing?.currency ?: "UGX")
        val duration = field("Duration in days", (existing?.durationDays ?: 30).toString(), android.text.InputType.TYPE_CLASS_NUMBER)
        val description = field("Description", existing?.description.orEmpty())
        val active = CheckBox(this).apply { text = "Available to customers"; isChecked = existing?.active ?: true }
        listOf(name, amount, currency, duration, description).forEach { box.addView(it) }
        box.addView(active)
        AlertDialog.Builder(this).setTitle(if (existing == null) "Add subscription" else "Edit subscription")
            .setView(box).setNegativeButton("CANCEL", null)
            .setPositiveButton("SAVE", null).create().also { dialog ->
                dialog.setOnShowListener {
                    dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                        val price = amount.text.toString().toDoubleOrNull()
                        val days = duration.text.toString().toIntOrNull()
                        if (name.text.isBlank() || price == null || price <= 0 || days == null || days <= 0) {
                            Toast.makeText(this, "Enter a name, valid price and duration", Toast.LENGTH_SHORT).show(); return@setOnClickListener
                        }
                        save(Subscription(existing?.id.orEmpty(), name.text.toString(), price, currency.text.toString(), description.text.toString(), days, active.isChecked))
                        dialog.dismiss()
                    }
                }
                dialog.show()
            }
    }

    private fun save(plan: Subscription) {
        lifecycleScope.launch {
            try { repo.saveSubscription(plan); Toast.makeText(this@SubscriptionsActivity, "Subscription saved", Toast.LENGTH_SHORT).show(); loadPlans() }
            catch (e: Exception) { Toast.makeText(this@SubscriptionsActivity, "Save failed: ${e.message}", Toast.LENGTH_LONG).show() }
        }
    }

    private fun confirmDelete(plan: Subscription) {
        AlertDialog.Builder(this).setTitle("Delete ${plan.name}?")
            .setMessage("This permanently removes the plan from the customer payment dialog.")
            .setNegativeButton("CANCEL", null).setPositiveButton("DELETE") { _, _ ->
                lifecycleScope.launch {
                    try { repo.deleteSubscription(plan.id); Toast.makeText(this@SubscriptionsActivity, "Subscription deleted", Toast.LENGTH_SHORT).show(); loadPlans() }
                    catch (e: Exception) { Toast.makeText(this@SubscriptionsActivity, "Delete failed: ${e.message}", Toast.LENGTH_LONG).show() }
                }
            }.show()
    }
}
