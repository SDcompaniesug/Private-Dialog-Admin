package com.privateadmin.android.ui

import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.drawerlayout.widget.DrawerLayout
import androidx.lifecycle.lifecycleScope
import com.google.firebase.auth.FirebaseAuth
import com.privateadmin.android.R
import com.privateadmin.android.data.FirebaseRepository
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private lateinit var drawer: DrawerLayout
    private lateinit var frame: FrameLayout
    private lateinit var pageTitle: TextView

    private val repo = FirebaseRepository()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_main)

        initializeViews()
        setupDrawer()
        showDashboard()
    }

    /**
     * Initialize all views from activity_main.xml
     */
    private fun initializeViews() {

        drawer = findViewById(R.id.drawer)

        frame = findViewById(R.id.contentFrame)

        pageTitle = findViewById(R.id.pageTitle)
    }

    /**
     * Configure the navigation drawer.
     */
    private fun setupDrawer() {

        // Top-left drawer/menu button
        findViewById<ImageButton>(R.id.menuButton)
            .setOnClickListener {
                if (drawer.isDrawerOpen(Gravity.START)) {
                    drawer.closeDrawer(Gravity.START)
                } else {
                    drawer.openDrawer(Gravity.START)
                }
            }

        // Dashboard
        findViewById<Button>(R.id.navDashboard)
            .setOnClickListener {
                showDashboard()
            }

        // Subscription plans and payment configuration
        findViewById<Button>(R.id.navSubscriptions).setOnClickListener {
            openActivity(SubscriptionsActivity::class.java)
        }

        // Users & devices
        findViewById<Button>(R.id.navUsers)
            .setOnClickListener {

                openActivity(
                    UsersActivity::class.java
                )
            }

        // App settings
        findViewById<Button>(R.id.navSettings)
            .setOnClickListener {

                openActivity(
                    AppSettingsActivity::class.java
                )
            }

        // Logout
        findViewById<Button>(R.id.navLogout)
            .setOnClickListener {

                ConfirmDialog.show(
                    this,
                    "Logout?",
                    "Are you sure you want to logout?"
                ) {

                    FirebaseAuth
                        .getInstance()
                        .signOut()

                    drawer.closeDrawers()

                    finish()
                }
            }
    }

    /**
     * Open another activity and close the drawer.
     */
    private fun openActivity(
        activityClass: Class<*>
    ) {

        try {

            startActivity(
                Intent(
                    this,
                    activityClass
                )
            )

            drawer.closeDrawers()

        } catch (e: Exception) {

            // Keep navigation quiet instead of showing
            // the "Could not load..." toast.
            drawer.closeDrawers()
        }
    }

    /**
     * Display dashboard.
     *
     * Statistics start at zero immediately.
     * Firebase values replace them when available.
     */
    private fun showDashboard() {

        pageTitle.text = "Dashboard"

        frame.removeAllViews()

        val dashboardView =
            layoutInflater.inflate(
                R.layout.page_dashboard,
                frame,
                false
            )

        frame.addView(dashboardView)

        drawer.closeDrawers()

        /*
         * Show zero immediately.
         *
         * This prevents the dashboard from appearing
         * empty while Firebase is being queried.
         */
        setDashboardStat(
            dashboardView,
            R.id.statUsers,
            "Users",
            0
        )

        setDashboardStat(
            dashboardView,
            R.id.statOnline,
            "Online",
            0
        )

        setDashboardStat(
            dashboardView,
            R.id.statActive,
            "Active plans",
            0
        )

        setDashboardStat(
            dashboardView,
            R.id.statBanned,
            "Inactive plans",
            0
        )

        /*
         * Load the actual values in the background.
         */
        lifecycleScope.launch {

            try {

                val subscriptions = repo.getSubscriptions()
                val users = repo.getUsers()

                /*
                 * Users
                 */
                setDashboardStat(
                    dashboardView,
                    R.id.statUsers,
                    "Users",
                    users.size
                )

                /*
                 * Online users
                 */
                setDashboardStat(
                    dashboardView,
                    R.id.statOnline,
                    "Online",
                    users.count {
                        it.online
                    }
                )

                setDashboardStat(dashboardView, R.id.statActive, "Active plans", subscriptions.count { it.active })
                setDashboardStat(dashboardView, R.id.statBanned, "Inactive plans", subscriptions.count { !it.active })

            } catch (_: Exception) {

                /*
                 * Do nothing.
                 *
                 * The dashboard already contains
                 * the default zero values.
                 *
                 * No toast is shown.
                 */
            }
        }
    }

    /**
     * Safely update a dashboard statistic.
     */
    private fun setDashboardStat(
        root: View,
        cardId: Int,
        title: String,
        value: Int
    ) {

        val card =
            root.findViewById<View>(cardId)
                ?: return

        val titleView =
            card.findViewById<TextView>(
                R.id.statTitle
            )

        val valueView =
            card.findViewById<TextView>(
                R.id.statValue
            )

        titleView?.text = title

        valueView?.text =
            value.toString()
    }

    /**
     * Handle returning to the main activity.
     */
    override fun onResume() {
        super.onResume()

        /*
         * Refresh dashboard whenever the user returns
         * from another management page.
         */
        if (::frame.isInitialized &&
            ::pageTitle.isInitialized
        ) {
            showDashboard()
        }
    }

    /**
     * Close the drawer when the activity is stopped.
     */
    override fun onStop() {
        if (::drawer.isInitialized) {
            drawer.closeDrawers()
        }

        super.onStop()
    }

    /**
     * Prevent accidental drawer state issues.
     */
    override fun onBackPressed() {

        if (::drawer.isInitialized &&
            drawer.isDrawerOpen(Gravity.START)
        ) {

            drawer.closeDrawer(Gravity.START)

        } else {

            super.onBackPressed()
        }
    }
}