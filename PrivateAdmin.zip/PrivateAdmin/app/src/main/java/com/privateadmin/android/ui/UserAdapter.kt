package com.privateadmin.android.ui

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.privateadmin.android.R
import com.privateadmin.android.data.AdminUser

class UserAdapter(private var items: List<AdminUser>, private val edit: (AdminUser) -> Unit, private val disable: (AdminUser) -> Unit) : RecyclerView.Adapter<UserAdapter.Holder>() {
    class Holder(view: View) : RecyclerView.ViewHolder(view) {
        val device: TextView = view.findViewById(R.id.deviceText)
        val packageName: TextView = view.findViewById(R.id.packageText)
        val status: TextView = view.findViewById(R.id.statusText)
        val edit: ImageButton = view.findViewById(R.id.editButton)
        val disable: ImageButton = view.findViewById(R.id.banButton)
    }
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) = Holder(LayoutInflater.from(parent.context).inflate(R.layout.item_user, parent, false))
    override fun getItemCount() = items.size
    override fun onBindViewHolder(holder: Holder, position: Int) { val user = items[position]; holder.device.text = "Device ID: ${user.deviceId}"; holder.packageName.text = "Package: ${user.packageName.ifBlank { "Not reported" }}"; holder.status.text = "${user.status} • ${if (user.online) "Online" else "Offline"}"; holder.edit.setOnClickListener { edit(user) }; holder.disable.setOnClickListener { disable(user) } }
    fun update(value: List<AdminUser>) { items = value; notifyDataSetChanged() }
}
