package com.privateadmin.android.ui

import android.content.Context
import androidx.appcompat.app.AlertDialog

object ConfirmDialog {
    fun show(
        context: Context,
        title: String,
        message: String,
        onConfirm: () -> Unit
    ) {
        AlertDialog.Builder(context)
            .setTitle(title)
            .setMessage(message)
            .setPositiveButton("Confirm") { _, _ -> onConfirm() }
            .setNegativeButton("Cancel", null)
            .show()
    }
}