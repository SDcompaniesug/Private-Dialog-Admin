package com.privateadmin.android.ui

import android.os.Bundle
import android.widget.EditText
import android.widget.LinearLayout
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.privateadmin.android.R
import com.privateadmin.android.data.AdminUser
import com.privateadmin.android.data.FirebaseRepository
import kotlinx.coroutines.launch

class UsersActivity : AppCompatActivity() {
    private val repo = FirebaseRepository()
    private lateinit var adapter: UserAdapter
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_users)
        adapter = UserAdapter(emptyList(), ::edit, ::disable)
        findViewById<RecyclerView>(R.id.usersList).apply { layoutManager = LinearLayoutManager(this@UsersActivity); adapter = this@UsersActivity.adapter }
    }
    override fun onResume() { super.onResume(); load() }
    private fun load() { lifecycleScope.launch { try { adapter.update(repo.getUsers()) } catch (_: Exception) { } } }
    private fun disable(user: AdminUser) { ConfirmDialog.show(this, "Disable user?", "Confirm disabling ${user.deviceId}.") { lifecycleScope.launch { try { repo.saveUser(user.copy(status = "disabled")); load() } catch (_: Exception) { } } } }
    private fun edit(user: AdminUser) {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 0, 24, 0) }
        val packageName = EditText(this).apply { setText(user.packageName); hint = "Package name" }
        val status = EditText(this).apply { setText(user.status); hint = "Status" }
        box.addView(packageName); box.addView(status)
        androidx.appcompat.app.AlertDialog.Builder(this).setTitle("Edit device").setView(box).setNegativeButton("Cancel", null).setPositiveButton("Save") { _, _ -> lifecycleScope.launch { try { repo.saveUser(user.copy(packageName = packageName.text.toString(), status = status.text.toString())); load() } catch (_: Exception) { } } }.show()
    }
}
