package com.privateadmin.android.ui

import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.privateadmin.android.R
import com.privateadmin.android.data.AppSettings
import com.privateadmin.android.data.FirebaseRepository
import kotlinx.coroutines.launch

class AppSettingsActivity : AppCompatActivity() {
    private val repo = FirebaseRepository()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        val title = findViewById<EditText>(R.id.titleInput)
        val contact = findViewById<EditText>(R.id.contactInput)
        val paymentApi = findViewById<EditText>(R.id.paymentApiInput)
        val appId = findViewById<EditText>(R.id.appIdInput)
        val message = findViewById<TextView>(R.id.message)

        title.setText("Subscription Access")
        lifecycleScope.launch {
            try {
                val saved = repo.getSettings()
                if (saved.title.isNotBlank()) title.setText(saved.title)
                contact.setText(saved.contact)
                paymentApi.setText(saved.paymentApiUrl)
                appId.setText(saved.appId)
            } catch (_: Exception) { }
        }

        findViewById<Button>(R.id.saveButton).setOnClickListener { view ->
            val button = view as Button
            val endpoint = paymentApi.text.toString().trim()
            if (endpoint.isNotEmpty() && !endpoint.startsWith("https://")) {
                paymentApi.error = "Payment API URL must use HTTPS"
                return@setOnClickListener
            }
            button.isEnabled = false
            button.text = "SAVING..."
            lifecycleScope.launch {
                try {
                    repo.saveSettings(AppSettings(
                        title = title.text.toString().trim().ifBlank { "Subscription Access" },
                        contact = contact.text.toString().trim(),
                        paymentApiUrl = endpoint,
                        appId = appId.text.toString().trim()
                    ))
                    message.text = "Settings saved to the shared database."
                    message.setTextColor(Color.rgb(22, 163, 74))
                    message.visibility = View.VISIBLE
                } catch (e: Exception) {
                    message.text = "Could not save settings: ${e.message}"
                    message.setTextColor(Color.rgb(185, 28, 28))
                    message.visibility = View.VISIBLE
                } finally {
                    button.isEnabled = true
                    button.text = "SAVE SETTINGS"
                }
            }
        }
    }
}
