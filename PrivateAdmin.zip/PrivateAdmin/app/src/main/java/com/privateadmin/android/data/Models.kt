package com.privateadmin.android.data

data class AdminUser(
    val deviceId: String = "",
    val packageName: String = "",
    val online: Boolean = false,
    val lastLogin: Long = 0L,
    val status: String = "active"
)

data class AppSettings(
    val title: String = "Private Login",
    val contact: String = "",
    val features: List<String> = emptyList(),
    val paymentApiUrl: String = "",
    val appId: String = ""
)

data class Subscription(
    val id: String = "",
    val name: String = "",
    val amount: Double = 0.0,
    val currency: String = "UGX",
    val description: String = "",
    val durationDays: Int = 30,
    val active: Boolean = true
)
