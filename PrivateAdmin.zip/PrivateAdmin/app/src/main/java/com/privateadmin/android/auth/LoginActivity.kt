package com.privateadmin.android.auth
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.privateadmin.android.R
import com.privateadmin.android.ui.MainActivity
class LoginActivity:AppCompatActivity(){private lateinit var auth:FirebaseAuth;override fun onCreate(b:Bundle?){super.onCreate(b);setContentView(R.layout.activity_login);auth=FirebaseAuth.getInstance();if(auth.currentUser!=null){openMain();return};val e=findViewById<EditText>(R.id.emailInput);val p=findViewById<EditText>(R.id.passwordInput);val btn=findViewById<Button>(R.id.loginButton);val msg=findViewById<TextView>(R.id.loginMessage);btn.setOnClickListener{msg.visibility=View.GONE;if(e.text.toString().trim().isEmpty()||p.text.toString().isEmpty()){msg.text="Enter your email and password.";msg.visibility=View.VISIBLE;return@setOnClickListener};btn.isEnabled=false;btn.text="Please wait...";auth.signInWithEmailAndPassword(e.text.toString().trim(),p.text.toString()).addOnCompleteListener{t->btn.isEnabled=true;btn.text="LOGIN";if(t.isSuccessful)openMain()else{msg.text="Sign in failed. Check your details and try again.";msg.visibility=View.VISIBLE}}}};private fun openMain(){startActivity(Intent(this,MainActivity::class.java));finish()}}
